## springboot 2.0 集成 mybatis

### 环境：

* 开发工具：Intellij IDEA 2017.1.3
* springboot: **2.0.1.RELEASE**
* jdk：1.8.0_40
* maven:3.3.9
* alibaba Druid 数据库连接池：1.1.9

### 额外功能：

* PageHelper 分页插件